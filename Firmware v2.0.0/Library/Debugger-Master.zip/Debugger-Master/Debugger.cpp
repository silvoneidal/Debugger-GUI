#include "Debugger.h"

// Instancia o objeto global Debugger
DebuggerClass Debugger;
